 g++ -g testmerge.cpp mergesort.cpp -lrt -o testmerge
